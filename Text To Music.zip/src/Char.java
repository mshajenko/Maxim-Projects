import java.util.ArrayList;
import java.util.Random;
import java.io.*;

/**
 * char class to handle the character objects
 * gives them notes and instruments, finds the octave and note
 * these objects allow the characters to become sounds by giving them the needed
 * variables
 * 
 * 
 * @author Maxim Shajenko
 * @version 6/9/2024
 */

public class Char {
    private int note;
    private int instrument;
    private char c;
    private String letterNote;
    private int octave;
    private Random random = new Random();
    private String fileName = "info.txt";
    PrintWriter writer = null;

    public Char(char c) {
        this.c = c;
        this.note = random.nextInt(128); // notes go up to 127
        this.instrument = random.nextInt(129); // instruments go up to 128
    }

    // secondary constructor that lets you give a char (to update the sound)
    public Char(char c, int note, int instrument) {
        this.c = c;
        this.note = note;
        this.instrument = instrument;
    }

    /*
     * randomly initializes all the chars with notes and instruments and writes them
     * to a file
     */
    public void init() {
        try {
            writer = new PrintWriter(fileName);

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        String characters = "`1234567890-=~!@#$%^&*()_+qwertyuiop[]\\{}|asdfghjkl;:'\"zxcvbnm,./<>?QWERTYUIOP{}|ASDFGHJKL:ZXCVBNM<>?";
        for (int i = 0; i < characters.length(); i++) {
            char newChar = characters.charAt(i);
            Char k = new Char(newChar);
            writer.println(k.toString());
        }
        writer.close();

    }

    /*
     * reads the notes from the file and returns an arraylist of char objects with
     * their note and instrument
     */
    public ArrayList<Char> getNotes() {
        ArrayList<Char> chars = new ArrayList<Char>();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) { // if its not null
                String[] parts = line.split("\\."); // splits the lines into parts by the period in between the data
                if (parts.length == 3) { // if it has all the needed data
                    // sets the object with all the data from the file
                    char c = parts[0].charAt(0);
                    int note = Integer.parseInt(parts[1]);
                    int instrument = Integer.parseInt(parts[2]);
                    chars.add(new Char(c, note, instrument));
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return chars;
    }

    public int getNote() {
        return note;
    }

    public int getInstrument() {
        return instrument;
    }

    public char getChar() {
        return c;
    }

    /*
     * toString() that allows it to be put into a file and read later
     */
    public String toString() {
        return c + "." + note + "." + instrument;
    }

    /*
     * sets a new note and instrument
     */
    public void setNew(int note, int instrument) {
        this.note = note;
        this.instrument = instrument;
    }

    /*
     * find what letter note it is
     */
    public String getLetterNote() {
        int numberNote = note % 12 + 1;
        switch (numberNote) {
            case 1:
                return "C";
            case 2:
                return "C#";
            case 3:
                return "D";
            case 4:
                return "D#";
            case 5:
                return "E";
            case 6:
                return "F";
            case 7:
                return "F#";
            case 8:
                return "G";
            case 9:
                return "G#";
            case 10:
                return "A";
            case 11:
                return "A#";
            case 12:
                return "B";
            default:
                return null;

        }
    }

    /*
     * find what octave the note is in
     */
    public int getOctave() {
        int octave = note / 12 + 1;
        return octave;
    }
}
