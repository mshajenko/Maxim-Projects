import java.io.File;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 * jusical jext jeditor
 * functions as a text editor that makes funny sounds
 * you can customize the font, colors, and sounds
 * 
 * 
 * @author Maxim Shajenko
 * @version 6/9/2024
 */
public class Jusic {
    public static void main(String[] args) throws Exception {
        JOptionPane.showMessageDialog(null,
                "welcome to jusic jext jeditor \n whatever you type in plays music \n it works like a normal text editor, just musical",
                "welcome", 1);
        File f = new File("info.txt");
        Sound sound = new Sound();
        Char character = new Char((char) 10002); // just a random character, it didnt take null
        if (f.length() == 0) // if there isnt anything in the file
            character.init();
        ArrayList<Char> chars = new ArrayList<Char>();
        chars = character.getNotes();
        Window win = new Window(chars, sound);
    }
}
