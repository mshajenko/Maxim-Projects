import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;

import javax.swing.JPanel;
import javax.swing.JSlider;

/**
 * display class to handle the screen display that you type in
 * 
 * 
 * @author Maxim Shajenko
 * @version 6/9/2024
 */

public class Display extends JPanel implements MouseMotionListener, KeyListener {
    int WIDTH, HEIGHT;
    ArrayList<String> lines = new ArrayList<>();
    Sound sound;
    ArrayList<Char> chars;
    FontMetrics metrics; // lets you get the size and width of rendering the font graphics
    JSlider speedSlider;
    Font currentFont;
    int currentFontSize;
    Color textColor;
    Color backgroundColor;

    public Display(int w, int h, ArrayList<Char> chars, Sound sound, JSlider speedSlider) {
        this.WIDTH = w;
        this.HEIGHT = h;
        this.chars = chars;
        this.sound = sound;
        this.speedSlider = speedSlider;
        this.currentFontSize = 100;
        this.currentFont = new Font("Papyrus", Font.PLAIN, currentFontSize);
        this.textColor = Color.WHITE;
        this.backgroundColor = Color.BLACK;

        this.addMouseMotionListener(this);
        this.addKeyListener(this);
        this.setBackground(backgroundColor);
        this.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        this.setVisible(true);

        lines.add("");

        this.setFocusTraversalKeysEnabled(false);
    }

    public void setFont(String fontName) {
        this.currentFont = new Font(fontName, Font.PLAIN, currentFontSize);
        repaint();
    }

    public void setFontSize(int fontSize) {
        this.currentFontSize = fontSize;
        this.currentFont = new Font(currentFont.getFontName(), Font.PLAIN, currentFontSize);
        repaint();
    }

    public void setTextColor(Color color) {
        this.textColor = color;
        repaint();
    }

    public Color getTextColor() {
        return this.textColor;
    }

    public void setBackgroundColor(Color color) {
        this.backgroundColor = color;
        this.setBackground(color);
        repaint();
    }

    public Color getBackgroundColor() {
        return this.backgroundColor;
    }

    @Override
    public void addNotify() {
        super.addNotify();
        this.requestFocusInWindow();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setFont(currentFont);
        g.setColor(textColor);
        metrics = g.getFontMetrics();
        int lineHeight = metrics.getHeight();
        // start in the middle
        int startX = WIDTH / 2;
        int startY = HEIGHT / 2 - (lines.size() * lineHeight) / 2;

        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);
            int lineWidth = metrics.stringWidth(line);
            int x = startX - lineWidth / 2; // put it in the middle accounting for the line width
            int y = startY + i * lineHeight; // move it down multiplied by the number of lines

            g.drawString(line, x, y);

            // check if its too much vertically
            if (startY + (i + 1) * lineHeight > HEIGHT) {
                currentFontSize = Math.max(currentFontSize - 10, 10); // if its too low, set it to 10
                currentFont = new Font(currentFont.getFontName(), Font.PLAIN, currentFontSize);
                metrics = g.getFontMetrics(currentFont);
                lineHeight = metrics.getHeight(); // height of the line for the current font and size of it
                startY = HEIGHT / 2 - (lines.size() * lineHeight) / 2; // start in the middle, move up for num lines
                repaint();
                return;
            }
        }
    }

    @Override
    public void mouseDragged(MouseEvent e) {
    }

    @Override
    public void mouseMoved(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_BACK_SPACE) { // if they pressed backspace
            if (!lines.isEmpty()) { // if lines is not empty
                String lastLine = lines.get(lines.size() - 1);
                if (!lastLine.isEmpty()) { // if the last line isn't empty
                    lines.set(lines.size() - 1, lastLine.substring(0, lastLine.length() - 1)); // set the line to a
                                                                                               // substring without the
                                                                                               // last char
                } else if (lines.size() > 1) {
                    lines.remove(lines.size() - 1); // remove the line
                }
            }
            sound.backSpaceSound(speedSlider.getValue()); // play the backspace sound

        } else if (e.getKeyCode() == KeyEvent.VK_TAB) {
            e.consume(); // consume the action so it doesnt start selecting buttons
            String currentLine = lines.get(lines.size() - 1) + "    "; // add 4
            lines.set(lines.size() - 1, currentLine); // set it to the current line
        } else if (e.getKeyCode() == KeyEvent.VK_ENTER) {
            lines.add(""); // adds a new line
        } else {
            char typedChar = e.getKeyChar();
            if (typedChar != KeyEvent.CHAR_UNDEFINED) { // if it is an actual character
                sound.strToSound("" + typedChar, chars, speedSlider.getValue()); // make the sound
                this.requestFocus();
                String currentLine = lines.get(lines.size() - 1) + typedChar; // add it to lines
                if (metrics.stringWidth(currentLine) > WIDTH - 40) { // if the line is too wide
                    lines.add("" + typedChar); // add a new line
                } else {
                    lines.set(lines.size() - 1, currentLine); // set the last line to the current line
                }
            }
        }
        repaint();
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    /*
     * plays all the lines
     */
    public void playAll() {
        for (String s : lines) {
            sound.strToSound(s, chars, speedSlider.getValue());
            this.requestFocusInWindow();
        }
    }

    public ArrayList<String> getLines() {
        return lines;
    }

    /*
     * clears all the lines
     */
    public void clearAllLines() {
        lines.clear();
        lines.add("");
        repaint();

    }
}
