import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;

import javax.sound.midi.Instrument;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.Synthesizer;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.ToolTipManager;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class Window extends JFrame {
    Display display;
    int WIDTH, HEIGHT;
    JTextField charField; // field to type in the char you want
    JTextField noteField; // field to pick the note you want
    JButton changeSoundButton; // button to change the sound
    JButton playAllButton; // button to play all sounds
    JButton textColorButton; // button to change text color
    JButton bgColorButton; // button to change background
    JButton visualizeButton; // button to graph the sounds
    JSlider speedSlider; // speed slider
    JButton clearButton; // button to clear all the text
    ArrayList<Char> chars;
    Sound sound;
    Random random;
    JComboBox<String> fontDropdown; // drop down to select font
    JComboBox<String> fontSizeDropdown; // drop down to select font size
    JComboBox<String> instrumentDropdown; // drop down to select intsruments
    Instrument[] instruments;

    /**
     * window class to handle jframe and the buttons you press
     * 
     * 
     * @author Maxim Shajenko
     * @version 6/9/2024
     */
    public Window(ArrayList<Char> chars, Sound sound) {
        this.chars = chars;
        this.sound = sound;
        this.random = new Random();

        WIDTH = 1000;
        HEIGHT = 1000;
        ToolTipManager.sharedInstance().setInitialDelay(50); // makes it so the tooltips pop up faster
        speedSlider = new JSlider(JSlider.HORIZONTAL, 50, 500, 250); // speed slider with min=50ms, max=500ms,
                                                                     // default=250ms
        speedSlider.setInverted(true); // invert the slider so it makes sense (higher value means more delay, slower
                                       // speed)
        speedSlider.setMajorTickSpacing(100);
        speedSlider.setPaintTicks(true);
        speedSlider.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                display.requestFocusInWindow();
            }
        });

        display = new Display(WIDTH, HEIGHT, chars, sound, speedSlider);
        this.setLayout(new BorderLayout());
        this.add(display, BorderLayout.CENTER);

        JPanel panel = new JPanel();
        JPanel rPanel = new JPanel();
        rPanel.setLayout(new BoxLayout(rPanel, BoxLayout.Y_AXIS)); // make it so that its vertical

        charField = new JTextField(10);
        noteField = new JTextField(3);
        changeSoundButton = new JButton("Change Sound");
        playAllButton = new JButton("Play All");
        textColorButton = new JButton("Change Text Color");
        bgColorButton = new JButton("Change Background Color");
        visualizeButton = new JButton("Visualize Sound");
        clearButton = new JButton("Clear");

        String[] fonts = { "Papyrus", "Serif", "SansSerif", "Monospaced", "Arial", "Courier New", "Georgia",
                "Times New Roman", "Verdana" };
        fontDropdown = new JComboBox<>(fonts);

        fontDropdown.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedFont = (String) fontDropdown.getSelectedItem();
                display.setFont(selectedFont);
                display.requestFocusInWindow();
            }
        });

        String[] fontSizes = { "50", "75", "100", "125", "150" };
        fontSizeDropdown = new JComboBox<>(fontSizes);

        fontSizeDropdown.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedSize = Integer.parseInt((String) fontSizeDropdown.getSelectedItem());
                display.setFontSize(selectedSize);
                display.requestFocusInWindow();
            }
        });

        instrumentDropdown = new JComboBox<>();
        instrumentDropdown.addItem("Random");
        // get all the names of the instruments and add them to the dropdown menu
        try {
            Synthesizer synthesizer = MidiSystem.getSynthesizer();
            synthesizer.open();
            instruments = synthesizer.getAvailableInstruments();
            for (Instrument instrument : instruments) {
                instrumentDropdown.addItem(instrument.getName());
            }
            synthesizer.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        textColorButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Color newColor = JColorChooser.showDialog(Window.this, "Choose Text Color", display.getTextColor());
                if (newColor != null) {
                    display.setTextColor(newColor);
                    display.requestFocusInWindow();
                }
            }
        });

        bgColorButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Color newColor = JColorChooser.showDialog(Window.this, "Choose Background Color",
                        display.getBackgroundColor());
                if (newColor != null) {
                    display.setBackgroundColor(newColor);
                    display.requestFocusInWindow();
                }
            }
        });

        visualizeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame graphFrame = new JFrame("Sound Graph");
                ArrayList<Char> letters = new ArrayList<Char>();
                for (String line : display.getLines()) { // go through all the lines
                    for (int i = 0; i < line.length(); i++) {
                        char currentChar = line.charAt(i);
                        for (int j = 0; j < chars.size(); j++) { // add all the letters to a list as char objects
                            if (currentChar == chars.get(j).getChar()) {
                                letters.add(chars.get(j));
                            }
                        }
                    }
                }
                Graph graph = new Graph(letters);
                graphFrame.add(graph);
                graphFrame.pack();
                graphFrame.setVisible(true);
                display.requestFocusInWindow();
            }
        });

        rPanel.add(fontDropdown);
        rPanel.add(fontSizeDropdown);
        rPanel.add(textColorButton);
        rPanel.add(bgColorButton);
        rPanel.add(visualizeButton);
        panel.add(clearButton);
        panel.add(new JLabel("Char:"));
        panel.add(charField);
        charField.setToolTipText("enter a single character");
        panel.add(new JLabel("Note:"));
        panel.add(noteField);
        noteField.setToolTipText("enter a number 0-127");
        panel.add(new JLabel("Instrument:"));
        panel.add(instrumentDropdown);
        panel.add(changeSoundButton);
        panel.add(playAllButton);
        panel.add(new JLabel("Speed:"));
        panel.add(speedSlider);

        this.add(panel, BorderLayout.NORTH);
        this.add(rPanel, BorderLayout.EAST);

        instrumentDropdown.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                display.requestFocusInWindow(); // give focus back to display
            }
        });

        changeSoundButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                changeCharacterSound();
                display.requestFocusInWindow(); // give focus back to display
            }
        });

        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                display.clearAllLines();
                display.requestFocusInWindow(); // give focus back to display
            }
        });

        playAllButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                display.playAll();
                display.requestFocusInWindow(); // give focus back to display
            }
        });

        this.setTitle("Simple Mouse Demo");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(WIDTH, HEIGHT);
        this.setVisible(true);

        display.requestFocusInWindow(); // gives focus to display
    }

    /*
     * updates the sound that a character makes by taking the value from the text
     * fields and dropdown menus
     */
    private void changeCharacterSound() {
        String text = charField.getText();
        String noteText = noteField.getText();
        int selectedInstrument = instrumentDropdown.getSelectedIndex();

        if (text.length() == 1) {
            try {
                int newNote;
                int newInstrument;
                if (noteText.isEmpty()) { // if its empty
                    newNote = random.nextInt(128); // pick a random number
                } else {
                    newNote = Integer.parseInt(noteText);

                }

                if (selectedInstrument == 0) {
                    newInstrument = random.nextInt(128);
                } else {
                    newInstrument = selectedInstrument - 1;
                }

                char character = text.charAt(0);

                for (Char c : chars) { // update all the chars with the new sound
                    if (c.getChar() == character) {
                        c.setNew(newNote, newInstrument);
                        break;
                    }
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid note");
            }
        }
    }
}
