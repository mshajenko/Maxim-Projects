import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;
import javax.swing.JPanel;

/**
 * graph class to do the sound visualizing
 * makes a new window and graphs all the sounds
 * 
 * 
 * @author Maxim Shajenko
 * @version 6/9/2024
 */

public class Graph extends JPanel {
    private ArrayList<Char> typedChars;

    public Graph(ArrayList<Char> typedChars) {
        this.typedChars = typedChars;
        this.setPreferredSize(new Dimension(1000, 1000));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        g.setColor(Color.BLACK);
        int width = getWidth();
        int height = getHeight();
        g.fillRect(0, 0, width, height);

        for (Char c : typedChars) {
            int x = c.getInstrument() * width / 128; // x is based off of the instrument
            int y = height - (c.getOctave() * height / 10); // y is based off of the octave, higher note, higher y val

            Color color = getColorForNote(c.getLetterNote());
            g2.setColor(color);
            g2.fillOval(x, y, 10, 10);
        }
    }

    private Color getColorForNote(String note) { // gets a color for each note
        switch (note) {
            case "C":
                return Color.RED;
            case "C#":
                return Color.ORANGE;
            case "D":
                return Color.YELLOW;
            case "D#":
                return Color.GREEN;
            case "E":
                return Color.CYAN;
            case "F":
                return Color.BLUE;
            case "F#":
                return Color.MAGENTA;
            case "G":
                return Color.PINK;
            case "G#":
                return Color.GRAY;
            case "A":
                return Color.LIGHT_GRAY;
            case "A#":
                return Color.DARK_GRAY;
            case "B":
                return Color.BLACK;
            default:
                return Color.WHITE;
        }
    }
}
