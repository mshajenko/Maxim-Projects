import java.util.ArrayList;

import javax.sound.midi.Instrument;
import javax.sound.midi.MidiChannel;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.Soundbank;
import javax.sound.midi.Synthesizer;
import javax.swing.JOptionPane;

/**
 * sound class for handling the midi sounds
 * all synths are made in here
 * 
 * 
 * @author Maxim Shajenko
 * @version 6/9/2024
 */
public class Sound {
    Synthesizer synth;
    MidiChannel channels[];
    Soundbank bank;
    Instrument instrs[];

    /*
     * creates the midi synth in the constructor to be used by the methods
     */
    public Sound() {
        try {
            synth = MidiSystem.getSynthesizer();
            synth.open();
            channels = synth.getChannels();
            bank = synth.getDefaultSoundbank();
            synth.loadAllInstruments(bank);
            instrs = synth.getLoadedInstruments();
        } catch (Exception e) {
            System.out.println("problem in constructor");
            JOptionPane.showMessageDialog(null, e, null, 0);
        }

    }

    /*
     * makes a funny sound for when you backspace
     */
    public void backSpaceSound(int speed) {
        try {
            synth.open();
            channels[0].programChange(instrs[3].getPatch().getProgram()); // honky tonk
            channels[0].noteOn(60, 100);
            try {
                Thread.sleep(speed);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            channels[0].noteOff(60);
            synth.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
     * converts a string to a sound and plays it into the midi synth
     */
    public void strToSound(String str, ArrayList<Char> chars, int speed) {
        for (int i = 0; i < str.length(); i++) {
            char currentChar = str.charAt(i);
            for (Char c : chars) { // goes through all the characters in the string
                if (c.getChar() == currentChar) {
                    try {
                        synth.open();
                        channels[0].programChange(instrs[c.getInstrument()].getPatch().getProgram());
                        channels[0].noteOn(c.getNote(), 100);

                        Thread.sleep(speed); // plays the sound for the amount of the speed variable

                        channels[0].noteOff(c.getNote()); // ends the note

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        synth.close(); // close the synth after you're done
    }
}
