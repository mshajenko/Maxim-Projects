import java.util.Random;
import java.util.Scanner;
import java.util.List;

/**
 * runs the flow of the game for jexas joldem'
 * handles player / bot actions and outcomes
 * 
 * @author Maxim Shajenko
 * @version 1/16/2023
 */

public class Game {
    private Scanner scanner = new Scanner(System.in);
    private Tasks tasks;

    private int pot = 0;
    private int allInPot = 0; // saves the pot for when a user is all in so they dont make extra
    private int currentBotBet = 0;

    public void startNewGame(String playerName) {
        int numBots;
        do {
            // gets the number of bots from the user
            System.out.print("Enter the number of bots (1-8): ");
            numBots = scanner.nextInt();

            if (numBots < 1 || numBots > 8) {
                System.out.println("Invalid number of bots. Please enter a number between 1 and 8.");
            }
        } while (numBots < 1 || numBots > 8); // keeps asking them until they put a valid number

        tasks = new Tasks(numBots);

        for (int i = 0; i <= numBots; i++) {
            // adds players (including poker bots) to the game
            Player newPlayer = (i == 0) ? new Player(1000) : new Bot(1000);
            tasks.addPlayer(newPlayer);
        }
        tasks.getPlayer(0).setBigBlind(true);
        tasks.getPlayer(1).setSmallBlind(true);
        int rounds = 0;

        while (true) {
            if (tasks.getPlayer(0).isFolded()) {
                System.out.println(playerName + " folds! Poker Bots Win!");
                distributePotToBots();
                rounds = 5;
            } else if (allBotsFolded()) {
                System.out.println("All Poker Bots Fold! " + playerName + " wins!");
                if (tasks.getPlayer(0).isAllIn())
                    tasks.getPlayer(0).setBalance(tasks.getPlayer(0).getBalance() + allInPot);
                else
                    tasks.getPlayer(0).setBalance(tasks.getPlayer(0).getBalance() + pot);
                rounds = 5;
            }
            System.out.println("Your balance: $" + tasks.getPlayer(0).getBalance());

            /*
             * goes through the different rounds of betting
             * reveals cards as the game progresses
             */
            switch (rounds) {
                case 0: {
                    tasks.initCards();
                    tasks.shuffleCards();
                    tasks.dealCards();

                    System.out.println("Your hand: " + tasks.getPlayer(0).getHand());
                    System.out.print(playerName + ": Call, Bet, Fold, or Check: ");
                    handlePlayerAction(tasks.getPlayer(0), rounds);

                    System.out.println("Poker Bots' moves...");
                    handlePokerBotsAction(rounds);

                    rounds += 1;
                    break;
                }

                case 1: {
                    tasks.getFlop();
                    tasks.revealFlop();
                    System.out.print(playerName + ": Call, Bet, Fold, or Check: ");
                    handlePlayerAction(tasks.getPlayer(0), rounds);

                    System.out.println("Poker Bots' moves...");
                    handlePokerBotsAction(rounds);

                    rounds += 1;
                    break;
                }

                case 2: {
                    tasks.getTurn();
                    tasks.revealTurn();

                    System.out.print(playerName + ": Call, Bet, Fold, or Check: ");
                    handlePlayerAction(tasks.getPlayer(0), rounds);

                    System.out.println("Poker Bots' moves...");
                    handlePokerBotsAction(rounds);

                    rounds += 1;
                    break;
                }

                case 3: {
                    tasks.getRiver();
                    tasks.revealCommunityCards();
                    System.out.print(playerName + ": Call, Bet, Fold, or Check: ");
                    handlePlayerAction(tasks.getPlayer(0), rounds);

                    System.out.println("Poker Bots' moves...");
                    handlePokerBotsAction(rounds);

                    rounds += 1;
                    break;
                }

                case 4: {
                    System.out.println(
                            playerName + "'s hand: " + tasks.getPlayer(0).getHand() + " "
                                    + tasks.checkHand(tasks.getPlayer(0).getHand(),
                                            tasks.getCommunityCards()));
                    tasks.revealBotHands();
                    revealCommunityCards();
                    determineWinner();
                    rounds += 1;
                    if (tasks.getPlayer(0).getBalance() >= 10000) {
                        System.out.println("Congratulations! " + playerName + " You've reached $10,000. You win!");
                        return;
                    }

                    if (tasks.getPlayer(0).getBalance() <= 0) {
                        System.out.println("Game Over! Your balance is $0. You lose!");
                        return;
                    }
                    break;
                }

                case 5: {
                    boolean validChoice = false;
                    do {
                        System.out.print("Would you like to play again? (yes or no): ");
                        String choice = scanner.next().toLowerCase();

                        if (choice.equals("yes")) {
                            // reset everything for the new round
                            tasks.reset();
                            rounds = 0;
                            pot = 0;
                            tasks.rotateBlinds();
                            validChoice = true; // exit the loop
                        } else if (choice.equals("no")) {
                            // end the game
                            System.out.println("Thanks for playing Jexas Joldem'!");
                            return;
                        } else {
                            // asks them again
                            System.out.println("Invalid Choice. Please enter 'yes' or 'no'.");
                        }
                    } while (!validChoice); // keeps asking them until they enter a valid choice
                    break;
                }

                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    /**
     * handles the player's action of choice and announces it
     * 
     * @param player
     * @param rounds
     */
    private void handlePlayerAction(Player player, int rounds) {
        if (player.isBigBlind() && rounds == 0) { // if they're big blind, they have to blind bet 20 first round
            System.out.println("Big Blind! Betting $20");
            try {
                Thread.sleep(1000); // sleep for 1 seconds so when their turn is skipped, they can read whats going
                                    // on
            } catch (InterruptedException e) {

                e.printStackTrace();
            }
            int bet = 20;
            if (bet >= player.getBalance()) { // exceeds balance, all in
                pot += player.getBalance();
                System.out.println("All-in!");
                player.setAllIn();
                player.bet(player.getBalance());

                allInPot = pot;

            } else {
                player.bet(bet);
                pot += bet;
            }
        } else if (player.isSmallBlind() && rounds == 0) { // if they're small blind, they have to blind bet 10 first
                                                           // round
            System.out.println("Small Blind! Betting $10");
            try {
                Thread.sleep(1000); // sleep for 1 seconds so when their turn is skipped, they can read whats going
                                    // on
            } catch (InterruptedException e) {

                e.printStackTrace();
            }
            int bet = 10;
            if (bet >= player.getBalance()) { // exceeds balance, all in
                pot += player.getBalance();
                System.out.println("All-in!");
                player.setAllIn();
                player.bet(player.getBalance());

                allInPot = pot;
            } else {
                player.bet(bet);
                pot += bet;
            }
        } else if (player.isAllIn()) { // if they're all in, they cant bet, so skip their turn
            System.out.println("All-in!");
            try {
                Thread.sleep(3000); // sleep for 3 seconds so when their turn is skipped, they can read whats going
                                    // on
            } catch (InterruptedException e) {

                e.printStackTrace();
            }
            return;
        }

        else {
            String action = scanner.next().toLowerCase();
            int betAmount;

            switch (action) {
                case "call":
                    betAmount = currentBotBet;
                    if (betAmount >= player.getBalance()) { // exceeds balance, all in
                        System.out.println("All-in!");
                        pot += player.getBalance();
                        player.setCurrentBet(player.getBalance());
                        player.bet(player.getBalance());
                        player.setAllIn();
                        allInPot = pot;
                    } else {
                        player.bet(betAmount);

                    }
                    pot += betAmount;
                    break;
                case "bet":
                    System.out.print("Enter bet amount: ");
                    betAmount = scanner.nextInt();
                    if (betAmount < currentBotBet || betAmount % 10 != 0) {
                        System.out.println("You must raise at least the current bet amount in multiples of 10.");
                        handlePlayerAction(player, rounds);
                        return;
                    }
                    int totalBet = player.getCurrentBet() + betAmount;
                    if (totalBet >= player.getBalance()) { // exceeds balance, all in
                        System.out.println("All-in!");
                        pot += player.getBalance();
                        player.setCurrentBet(player.getBalance());
                        player.bet(player.getBalance());
                        player.setAllIn();
                        allInPot = pot;
                    } else {
                        player.raise(betAmount);
                    }
                    pot += player.getCurrentBet();
                    break;
                case "fold":
                    player.fold();
                    break;
                case "check":
                    if (currentBotBet > player.getCurrentBet()) { // if a bot raised or something
                        System.out.println("You can't check. Try again.");
                        handlePlayerAction(player, rounds);
                        return;
                    }
                    player.check();
                    break;
                default:
                    System.out.println("Invalid action. Try again.");
                    handlePlayerAction(player, rounds);
            }
        }

    }

    /**
     * announces the actions of all the bots
     * 
     * @param rounds
     */
    private void handlePokerBotsAction(int rounds) {
        if (tasks.getPlayer(0).isFolded()) // skips the bot if its folded
            return;
        for (int i = 1; i <= tasks.getNumBots(); i++) { // goes through each bot
            Player currentPlayer = tasks.getPlayer(i);
            if (currentPlayer instanceof Bot && !currentPlayer.isFolded()) { // if its a bot and not folded
                Bot bot = (Bot) currentPlayer; // parse the player to a bot
                System.out.print("Poker Bot " + i + "'s move: ");
                makeBotMove(bot, tasks.getPlayer(0).getCurrentBet(), rounds);
            }
        }

    }

    /**
     * makes the bot's move and prints it out, uses some basic logic that raises or
     * folds based on the cards the bot has, if it has some cards that are just
     * okay, then makes moves randomly
     * 
     * @param bot
     * @param currentBet
     * @param rounds
     */
    private void makeBotMove(Bot bot, int currentBet, int rounds) {
        Random random = new Random();
        int randomAction = random.nextInt(3); // past some basic logic, it choses randomly
        List<String> botHand = bot.getHand();
        String card1 = botHand.get(0);
        String card2 = botHand.get(1);
        char rank1 = card1.charAt(0);
        char rank2 = card2.charAt(0);
        int holeCardsValue = tasks.findCardValue(rank1) + tasks.findCardValue(rank2);
        if (bot.isBigBlind() && rounds == 0) { // if they're big blind, they have to blind bet 20 first
                                               // round
            System.out.println("Big Blind! Betting $20");
            int bet = 20;
            bot.bet(bet);
            pot += bet;
        } else if (bot.isSmallBlind() && rounds == 0) { // if they're small blind, they have to blind bet 10 first
                                                        // round
            System.out.println("Small Blind! Betting $10");
            int bet = 10;
            bot.bet(bet);
            pot += bet;
        } else {
            if (holeCardsValue >= 20) { // if it has a 10 pair or better
                int raiseAmount = Math.min(50, currentBet + 10);
                System.out.println("Poker Bot raises $" + raiseAmount);
                bot.raise(raiseAmount);
                currentBotBet = raiseAmount;
                pot += raiseAmount;
            } else if (holeCardsValue <= 8) { // if it has a 4 pair or worse
                bot.fold();
                System.out.println("Poker Bot folds.");
            } else if (tasks.getPlayer(0).getCurrentBet() == 0 && currentBotBet == 0) {
                System.out.println("Poker Bot checks.");
                bot.check();
                currentBotBet = 0;
            } else if (randomAction == 1) {
                int callAmount = Math.min(currentBet, bot.getBalance());
                System.out.println("Poker Bot calls $" + callAmount);
                bot.call(callAmount);
                currentBotBet = callAmount;
                pot += callAmount;
            } else {
                bot.fold();
                System.out.println("Poker Bot folds.");
            }
        }
    }

    /*
     * gives the pot to the bots if they win
     */
    private void distributePotToBots() {
        for (int i = 1; i <= tasks.getNumBots(); i++) {
            if (!tasks.getPlayer(i).isFolded()) {
                tasks.getPlayer(i).setBalance(tasks.getPlayer(i).getBalance() + pot / (tasks.getNumBots() - 1));
            }
        }
    }

    /*
     * shows all the community cards
     */
    private void revealCommunityCards() {
        tasks.revealCommunityCards();
    }

    private void determineWinner() {
        int winningPlayer = 0; // index of the winning player in the players list
        int result = 0;

        for (int i = 1; i <= tasks.getNumBots(); i++) { // compares the player hand against all the bot hands
            if (!tasks.getPlayer(i).isFolded()) {
                result = tasks.compareHands(tasks.getPlayer(0).getHand(), tasks.getPlayer(i).getHand());

                if (result < 0) {
                    winningPlayer = i;
                }
            }
        }
        if (winningPlayer != 0) { // the winning player is a bot
            for (int i = 1; i <= tasks.getNumBots(); i++) { // compares all the bots against each other
                for (int j = i + 1; j <= tasks.getNumBots(); j++) {

                    if (!tasks.getPlayer(i).isFolded() && !tasks.getPlayer(j).isFolded()) {

                        // compares two bots with each other
                        if (i != j)
                            result = tasks.compareHands(tasks.getPlayer(i).getHand(), tasks.getPlayer(j).getHand());

                        if (result < 0) {
                            winningPlayer = i;
                        }
                    }
                }
            }
        }
        if (winningPlayer == 0)

        {
            System.out.println("Player Wins!");
            if (tasks.getPlayer(0).isAllIn())
                tasks.getPlayer(0).setBalance(tasks.getPlayer(0).getBalance() + allInPot);
            else
                tasks.getPlayer(0).setBalance(tasks.getPlayer(0).getBalance() + pot);
        } else {
            System.out.println("Poker Bot " + winningPlayer + " Wins!");
            tasks.getPlayer(winningPlayer).setBalance(tasks.getPlayer(winningPlayer).getBalance() + pot);
        }
    }

    /**
     * checks if all the bots are foled
     * 
     * @return if they're folded
     */
    private boolean allBotsFolded() {
        for (int i = 1; i <= tasks.getNumBots(); i++) {
            if (!tasks.getPlayer(i).isFolded()) {
                return false;
            }
        }
        return true;
    }

}
