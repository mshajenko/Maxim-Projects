import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * tasks class represents the main game logic and tasks for jexas joldem'.
 * creates the cards and has logic for deterimining hands
 * includes logic to proceed to different rounds of betting, like showing flop,
 * river, and turn
 * 
 * @author Maxim Shajenko
 * @version 1/16/2023
 */

public class Tasks {
    private String[] cards; // all the cards in the deck
    public List<Player> players = new ArrayList<>();
    private List<String> communityCards = new ArrayList<>(); // community cards that get revealed during the game
    private int numBots;
    private int currentBet = 0; // the player or bot's current bet

    public Tasks(int numBots) {
        this.numBots = numBots;
    }

    public int getNumBots() {
        return numBots;
    }

    /*
     * resets all the players
     */
    public void reset() {
        for (Player player : players) { // go through the list of players
            player.reset();
        }
        communityCards.clear();
    }

    /**
     * gets the highest bet out of all the players
     * 
     * @return int highest bet
     */
    public int getHighestBet() {
        int highestBet = 0;
        for (Player player : players) { // go through the list of players
            highestBet = Math.max(highestBet, player.getCurrentBet()); // get the larger bet of the two
        }
        return highestBet;
    }

    /**
     * get the player at the index
     * 
     * @param index
     * @return the player at the index, null if its not a valid index
     */
    public Player getPlayer(int index) {
        if (index >= 0 && index < players.size()) {
            return players.get(index);
        } else { // if its not a valid index, return null
            return null;
        }
    }

    /*
     * reveals the hole cards and hands of the bots
     */
    public void revealBotHands() {

        for (int i = 1; i <= numBots; i++) { // go through the bots
            if (!getPlayer(i).isFolded())
                System.out.println("Poker Bot " + i + "'s hand: " + getPlayer(i).getHand() + " "
                        + checkHand(getPlayer(i).getHand(), communityCards)); // reveal hole cards and hand

        }
    }

    /**
     * creates a new deck of cards
     * unicode chars are used to show the suit
     */
    public void initCards() {
        cards = new String[52];
        for (int i = 0; i < 13; i++) {
            for (int j = 0; j < 4; j++) {
                if (i + 1 == 1)
                    cards[i * 4 + j] = "A" + (char) (9828 + j);
                else if (i + 1 == 13)
                    cards[i * 4 + j] = "K" + (char) (9828 + j);
                else if (i + 1 == 12)
                    cards[i * 4 + j] = "Q" + (char) (9828 + j);
                else if (i + 1 == 11)
                    cards[i * 4 + j] = "J" + (char) (9828 + j);
                else
                    cards[i * 4 + j] = "" + (i + 1) + (char) (9828 + j);
            }
        }
    }

    /**
     * compares which of two hands is better, if their the same type, it compares
     * the kicker cards
     * 
     * @param hand1
     * @param hand2
     * @return which hand is better, if they're the same it compares the kickers
     */
    public int compareHands(List<String> hand1, List<String> hand2) {
        int result = compareHandsByType(hand1, hand2);

        if (result == 0) { // if its a tie, compare the kicker cards
            result = compareKickers(hand1, hand2, communityCards);
        }

        return result;
    }

    /**
     * compares hands by their type (one pair > high card)
     * 
     * @param hand1
     * @param hand2
     * @return which hand is better (-1, hand 1 is better, 1, hand 2 is better, 0,
     *         its a tie)
     */
    private int compareHandsByType(List<String> hand1, List<String> hand2) {
        String type1 = checkHand(hand1, communityCards);
        String type2 = checkHand(hand2, communityCards);
        int value1 = getHandRank(type1);
        int value2 = getHandRank(type2);
        if (value1 > value2) {
            return 1;
        } else if (value1 < value2) {
            return -1;
        }
        return 0;
    }

    /**
     * compares the value of the cards if they have a same hand EX: both players
     * have a one pair but one is an ace pair so that player wins
     * 
     * @param hand1
     * @param hand2
     * @param communityCards
     * @return which hand out of the two is better, or if they're the same
     */
    private int compareKickers(List<String> hand1, List<String> hand2, List<String> communityCards) {
        // adds up all the cards in the hand to an array list
        List<String> allCards1 = new ArrayList<>(hand1);
        allCards1.addAll(communityCards);

        List<String> allCards2 = new ArrayList<>(hand2);
        allCards2.addAll(communityCards);

        // compares all the card values within allCards
        for (int i = allCards1.size() - 1; i >= 0; i--) {
            int value1 = findCardValue(allCards1.get(i).charAt(0));
            int value2 = findCardValue(allCards2.get(i).charAt(0));

            if (value1 > value2) {
                return 1;
            } else if (value1 < value2) {
                return -1;
            }
        }

        return 0; // both hands are the same
    }

    /**
     * assigns a value to each hand type based on how good they are
     * 
     * @param handType
     * @return the hand's value
     */
    private int getHandRank(String handType) {
        switch (handType) {
            case "Royal Flush":
                return 10;
            case "Straight Flush":
                return 9;
            case "Four of a Kind":
                return 8;
            case "Full House":
                return 7;
            case "Flush":
                return 6;
            case "Straight":
                return 5;
            case "Three of a Kind":
                return 4;
            case "Two Pairs":
                return 3;
            case "One Pair":
                return 2;
            case "High Card":
                return 1;
            default:
                throw new IllegalArgumentException("Invalid hand type: " + handType);
        }
    }

    /**
     * assigns a value to every card based on how good it is
     * 
     * @param currentCard
     * @return the card's value
     */
    public int findCardValue(char currentCard) {
        char rank = currentCard;
        switch (rank) {
            case '2':
                return 2;
            case '3':
                return 3;
            case '4':
                return 4;
            case '5':
                return 5;
            case '6':
                return 6;
            case '7':
                return 7;
            case '8':
                return 8;
            case '9':
                return 9;
            case '1':
                return 10;
            case 'J':
                return 11;
            case 'Q':
                return 12;
            case 'K':
                return 13;
            case 'A':
                return 14;
            default:
                return 0;
        }
    }

    /**
     * checks what hand a player has
     * 
     * @param playerHand
     * @param communityCards
     * @return the name of their hand
     */
    public String checkHand(List<String> playerHand, List<String> communityCards) {
        List<String> combinedHand = new ArrayList<>(playerHand);
        combinedHand.addAll(communityCards);

        Collections.sort(combinedHand, (card1, card2) -> { // sort combined hand by card value ascending, to be used
                                                           // later to check if its a flush
            char rank1 = card1.charAt(0);
            char rank2 = card2.charAt(0);
            return Integer.compare(findCardValue(rank1), findCardValue(rank2));
        });

        if (hasRoyalFlush(combinedHand)) {
            return "Royal Flush";
        } else if (hasStraightFlush(combinedHand)) {
            return "Straight Flush";
        } else if (hasFourOfAKind(combinedHand)) {
            return "Four of a Kind";
        } else if (hasFullHouse(combinedHand)) {
            return "Full House";
        } else if (hasFlush(combinedHand)) {
            return "Flush";
        } else if (hasStraight(combinedHand)) {
            return "Straight";
        } else if (hasThreeOfAKind(combinedHand)) {
            return "Three of a Kind";
        } else if (hasTwoPairs(combinedHand)) {
            return "Two Pairs";
        } else if (hasOnePair(combinedHand)) {
            return "One Pair";
        } else {
            return "High Card";
        }
    }

    /**
     * checks if the player has a royal flush (straight flush with the lowest value
     * card being 10)
     * 
     * @param hand
     * @return bool if the player has a royal flush
     */
    private boolean hasRoyalFlush(List<String> hand) {
        return hasStraightFlush(hand) && findCardValue(hand.get(0).charAt(0)) == 1; // its a straight and the first card
                                                                                    // in the hand is a 10
    }

    /**
     * checks if the player has a straight flush (hasStraight && hasFlush)
     * 
     * @param hand
     * @return bool if the player has a straight flush
     */
    private boolean hasStraightFlush(List<String> hand) {
        return hasStraight(hand) && hasFlush(hand); // its a straight and a flush
    }

    /**
     * checks if the player has a full house
     * 
     * @param hand
     * @return bool if the player has a full house
     */
    private boolean hasFullHouse(List<String> hand) {
        int threeCount = 0;
        int pairCount = 0;

        for (int i = 0; i <= hand.size() - 3; i++) { // checks if it has three of a kind
            if (hand.get(i).charAt(0) == hand.get(i + 1).charAt(0) &&
                    hand.get(i + 1).charAt(0) == hand.get(i + 2).charAt(0)) {
                threeCount++;
            }
        }

        for (int i = 0; i <= hand.size() - 2; i++) { // checks if it has 2 of a kind
            if (hand.get(i).charAt(0) == hand.get(i + 1).charAt(0)) {
                pairCount++;
                i++;
            }
        }

        return threeCount >= 1 && pairCount >= 2; // pair count >= 2 because there is a pair within the three of a kind
    }

    /**
     * checks if the player has a four of a kind
     * 
     * @param hand
     * @return bool if the player has a four of a kind
     */
    private static boolean hasFourOfAKind(List<String> hand) {
        for (int i = 0; i <= hand.size() - 4; i++) {
            if (hand.get(i).charAt(0) == hand.get(i + 1).charAt(0) &&
                    hand.get(i + 1).charAt(0) == hand.get(i + 2).charAt(0) &&
                    hand.get(i + 2).charAt(0) == hand.get(i + 3).charAt(0)) {
                return true; // if they have 4 of the same card
            }
        }
        return false;
    }

    /**
     * checks if the hand is a flush
     * 
     * @param hand
     * @return boolean if the hand is a flush
     */
    private boolean hasFlush(List<String> hand) {
        int[] suitCount = new int[4];

        for (String card : hand) {
            String suit;
            if (card.charAt(1) == '0') // if its a 10
                suit = "" + card.charAt(2);
            else
                suit = "" + card.charAt(1);
            int suitIndex = getSuit(suit);
            suitCount[suitIndex]++;
            if (suitCount[suitIndex] > 4) { // if theres 5 of the same suit
                return true;
            }
        }

        return false;
    }

    /**
     * gives the suits a value to be used to check for a flush
     * 
     * @param suit
     * @return the suit's value
     */
    private int getSuit(String suit) {
        switch (suit) {
            case "♥":
                return 0;
            case "♦":
                return 1;
            case "♧":
                return 2;
            case "♤":
                return 3;
            default:
                throw new IllegalArgumentException("Invalid suit: " + suit);
        }
    }

    /**
     * checks if the hand is a straight
     * 
     * @param hand
     * @return boolean if the hand is a straight
     */
    private boolean hasStraight(List<String> hand) {
        // go through each possible starting position for a straight
        for (int i = 0; i <= hand.size() - 5; i++) {
            int startValue = findCardValue(hand.get(i).charAt(0));
            boolean isStraight = true;

            // check if the next four cards form a straight
            for (int j = 1; j < 5; j++) {
                int nextValue = findCardValue(hand.get(i + j).charAt(0));

                // ff the next card is not consecutive, the hand is not a straight
                if (nextValue != startValue + j) {
                    isStraight = false;
                    break;
                }
            }

            // if the hand forms a straight, return true
            if (isStraight) {
                return true;
            }
        }

        // no straight found
        return false;
    }

    /**
     * checks if the hand is a three of a kind
     * 
     * @param hand
     * @return bool if the hand is a three of a kind
     */
    private boolean hasThreeOfAKind(List<String> hand) {
        for (int i = 0; i <= hand.size() - 3; i++) {
            if (hand.get(i).charAt(0) == hand.get(i + 1).charAt(0) &&
                    hand.get(i + 1).charAt(0) == hand.get(i + 2).charAt(0)) {
                return true;
            }
        }
        return false;
    }

    /**
     * checks if the hand is a two pair
     * 
     * @param hand
     * @return bool if the hand is a two pair
     */
    private boolean hasTwoPairs(List<String> hand) {
        int pairCount = 0;
        for (int i = 0; i <= hand.size() - 2; i++) {
            if (hand.get(i).charAt(0) == hand.get(i + 1).charAt(0)) {
                pairCount++;
                i++;
            }
        }
        return pairCount >= 2;
    }

    /**
     * checks if the user has a pair
     * 
     * @param hand
     * @return bool if the user has a pair
     */
    private boolean hasOnePair(List<String> hand) {
        for (int i = 0; i <= hand.size() - 2; i++) {
            if (hand.get(i).charAt(0) == hand.get(i + 1).charAt(0)) {
                return true;
            }
        }
        return false;
    }

    public void addPlayer(Player player) {
        players.add(player);
    }

    /**
     * shuffles all the cards in a deck
     * adds them to the cards array
     */
    public void shuffleCards() {
        List<String> shuffledCards = new ArrayList<>(List.of(cards));
        Collections.shuffle(shuffledCards);
        cards = shuffledCards.toArray(new String[0]);
    }

    public void dealCards() {
        List<String> shuffledCards = new ArrayList<>(Arrays.asList(cards));
        Collections.shuffle(shuffledCards);

        for (Player player : players) {
            List<String> hand = new ArrayList<>();
            for (int i = 0; i < 2; i++) {
                String card = shuffledCards.remove(0);
                hand.add(card);
            }
            player.setHand(hand);
        }

        // deals cards to the bots
        for (int i = 1; i <= numBots; i++) {
            Bot bot = (Bot) players.get(i);
            List<String> hand = new ArrayList<>();
            for (int j = 0; j < 2; j++) {
                String card = shuffledCards.remove(0);
                hand.add(card);
            }
            bot.setHand(hand);
        }
    }

    public void getFlop() {
        for (int i = 0; i < 3; i++) {
            String card = cards[cards.length - 1];
            communityCards.add(card);
            cards = Arrays.copyOf(cards, cards.length - 1);
        }
    }

    public void getTurn() {
        String card = cards[cards.length - 1];
        communityCards.add(card);
        cards = Arrays.copyOf(cards, cards.length - 1);
    }

    public void getRiver() {
        String card = cards[cards.length - 1];
        communityCards.add(card);
        cards = Arrays.copyOf(cards, cards.length - 1);
    }

    public void revealCommunityCards() {
        System.out.println("Community Cards: " + communityCards);
    }

    public void revealFlop() {
        System.out
                .println("Flop: " + communityCards.get(0) + " " + communityCards.get(1) + " " + communityCards.get(2));
    }

    public void revealTurn() {
        System.out.println(
                "Turn: " + communityCards.get(0) + " " + communityCards.get(1) + " " + communityCards.get(2) + " " +
                        communityCards.get(3));
    }

    public List<String> getCommunityCards() {
        return communityCards;
    }

    public int getCurrentBet() {
        return currentBet;
    }

    public void updateCurrentBet(int newBet) {
        currentBet = newBet;
    }

    /*
     * rotates which players are big and small blinds
     * 
     */
    public void rotateBlinds() {
        int numPlayers = players.size();
        int smallBlindIndex = 0;
        int bigBlindIndex = 0;

        // find the current blind bet indexes
        for (int i = 0; i < numPlayers; i++) {
            if (players.get(i).isSmallBlind()) {
                smallBlindIndex = i;
            } else if (players.get(i).isBigBlind()) {
                bigBlindIndex = i;
            }
        }

        // rotate blind bets
        smallBlindIndex = (smallBlindIndex + 1) % numPlayers;
        bigBlindIndex = (bigBlindIndex + 1) % numPlayers;

        // reset blind bets
        for (Player player : players) {
            player.setBigBlind(false);
            player.setSmallBlind(false);
        }

        // update blind bets
        players.get(smallBlindIndex).setSmallBlind(true);
        players.get(bigBlindIndex).setBigBlind(true);
    }

    // other methods for managing the game can be added here
}
