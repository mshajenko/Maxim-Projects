import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * bot class has getters and setters for the bot
 * also holds bot actions like betting and folding
 * extends player class
 * 
 * @author Maxim Shajenko
 * @version 1/16/2023
 */

public class Bot extends Player {
    private List<String> hand;
    private int balance;
    private boolean isBigBlind;
    private boolean isSmallBlind;
    private boolean folded;
    private int currentBet; // current bot bet

    public Bot(int balance) {
        super(balance);
        this.hand = new ArrayList<>();
        this.balance = 100000; // give the bot "unlimited" money
        this.folded = false;
        this.currentBet = 0;
    }

    public List<String> getHand() {
        return Collections.unmodifiableList(hand);
    }

    public void addCardToHand(String card) {
        this.hand.add(card);
    }

    public int getBalance() {
        return balance;
    }

    public void setHand(List<String> hand) {
        this.hand = hand;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public boolean isFolded() {
        return folded;
    }

    public void setFolded(boolean folded) {
        this.folded = folded;
    }

    public int getCurrentBet() {
        return currentBet;
    }

    public void setCurrentBet(int currentBet) {
        this.currentBet = currentBet;
    }

    /**
     * bets the desired amount and deducts from the bot's balance
     * 
     * @param amount amount the bot wants to bet
     */
    public void bet(int amount) {
        setBalance(getBalance() - amount);
        setCurrentBet(amount);
    }

    public void check() {
        bet(0);
    }

    /**
     * resets the bot for a new game of poker
     */
    public void reset() {
        this.hand.clear();
        this.folded = false;
        this.isBigBlind = false;
        this.isSmallBlind = false;
        this.currentBet = 0;

    }

    public void fold() {
        setFolded(true);
    }

    /**
     * calls the amount that the other players bet
     * 
     * @param amount amount the other players bet
     */
    public void call(int amount) {

        this.balance -= amount;
    }

}