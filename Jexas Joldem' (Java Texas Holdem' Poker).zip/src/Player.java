import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * player class has getters and setters for player
 * also holds player actions like betting and folding
 * 
 * @author Maxim Shajenko
 * @version 1/16/2023
 */

class Player {

    private List<String> hand; // player's 2 hole cards
    private int balance;
    private boolean folded;
    private boolean isBigBlind;
    private boolean isSmallBlind;
    private int currentBet; // player's current bet
    private boolean allIn; // is the player all in

    public Player(int balance) {
        this.hand = new ArrayList<>();
        this.balance = balance;
        this.folded = false;
        this.isBigBlind = false;
        this.isSmallBlind = false;
        this.currentBet = 0;
        this.allIn = false;
    }

    public List<String> getHand() {
        return Collections.unmodifiableList(hand);
    }

    public void addCardToHand(String card) {
        this.hand.add(card);
    }

    public int getBalance() {
        return balance;
    }

    public void setHand(List<String> hand) {
        this.hand = hand;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public boolean isFolded() {
        return folded;
    }

    public void setFolded(boolean folded) {
        this.folded = folded;
    }

    public boolean isBigBlind() {
        return isBigBlind;
    }

    public void setBigBlind(boolean bigBlind) {
        isBigBlind = bigBlind;
    }

    public boolean isSmallBlind() {
        return isSmallBlind;
    }

    public void setSmallBlind(boolean smallBlind) {
        isSmallBlind = smallBlind;
    }

    public int getCurrentBet() {
        return currentBet;
    }

    public void setCurrentBet(int currentBet) {
        this.currentBet = currentBet;
    }

    /**
     * bets the desired amount and deducts from the player's balance
     * 
     * @param amount amount the player wants to bet
     */
    public void bet(int amount) {
        if (amount < 0) {
            throw new IllegalArgumentException("Bet amount cannot be negative");
        }

        if (amount > balance) {
            throw new IllegalArgumentException("Insufficient balance");
        }

        setBalance(getBalance() - amount);
        setCurrentBet(amount);
    }

    /**
     * raises the player's current bet by the desired amount
     * 
     * @param amount amount the player wants to raise
     */
    public void raise(int amount) {
        if (amount < 0) {
            throw new IllegalArgumentException("Raise amount cannot be negative");
        }

        int totalBet = getCurrentBet() + amount;
        bet(totalBet);
    }

    /**
     * calls the amount that the other players bet
     * 
     * @param amount amount the other players bet
     */
    public void call(int amount) {
        if (amount > balance) {
            throw new IllegalArgumentException("Insufficient balance to call");
        }

        this.balance -= amount;
    }

    /**
     * checks (bets 0)
     */
    public void check() {
        bet(0);
    }

    public void fold() {
        setFolded(true);
    }

    /**
     * resets the player for a new game of poker
     */
    public void reset() {
        this.hand.clear();
        this.folded = false;
        this.allIn = false;
        this.isBigBlind = false;
        this.isSmallBlind = false;
        this.currentBet = 0;

    }

    public boolean isAllIn() {
        return allIn;
    }

    public void setAllIn() {
        this.allIn = true;
    }
}