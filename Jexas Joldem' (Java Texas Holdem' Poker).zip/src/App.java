import java.util.Scanner;

/**
 * runner of the text based poker game: "jexas joldem'"" project
 * gets the players name and tells them the goal
 * 
 * @author Maxim Shajenko
 * @version 1/16/2023
 */

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to Jexas Joldem'");
        System.out.print("Enter your name: ");
        String playerName = scanner.nextLine();

        System.out.println("Your goal, " + playerName + ", is to make $10,000");
        System.out.println("You have a starting balance of $1,000...");
        System.out.println("Good luck!");

        Game newGame = new Game();
        newGame.startNewGame(playerName);
    }
}
